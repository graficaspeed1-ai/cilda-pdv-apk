CILDA VENDAS — PROJETO ANDROID

Este projeto empacota o módulo web fornecido em um aplicativo Android WebView.
Inclui permissões de câmera, armazenamento local, JavaScript e sincronização pelo mesmo Supabase do PDV.

COMO GERAR APK
1. Envie todos os arquivos desta pasta para um repositório GitHub novo, na branch main.
2. Abra Actions e execute "Build CILDA Vendas APK" (ou aguarde o build automático após push).
3. Abra a execução concluída e baixe o artefato "CILDA-Vendas-APK".
4. Extraia app-debug.apk e instale no Android.

NOTAS IMPORTANTES
- O APK gerado pelo workflow é de teste (debug), não uma versão assinada para Play Store.
- Entre com a mesma conta da loja usada no PDV para sincronizar.
- A câmera requer permissão do Android e suporte do WebView a BarcodeDetector.
- A sincronização depende de internet e das configurações atuais do Supabase.
- Teste primeiro com produtos/vendas de teste.

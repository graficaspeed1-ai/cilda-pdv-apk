// Proxy do Supabase para o PDV CILDA BIJU (Cloudflare Workers, plano gratuito).
// Serve para aparelhos/operadoras que não conseguem resolver *.supabase.co.
// Só repassa as rotas que o app usa e não guarda nenhum dado.
const TARGET = 'https://cxawkwfrvdvrnxpofadr.supabase.co';
const ALLOWED_PATHS = /^\/(auth\/v1|rest\/v1|realtime\/v1)\//;
// Opcional: restrinja ao domínio do seu app, ex.: ['https://meu-pdv.exemplo.com']. Vazio = qualquer origem.
const ALLOWED_ORIGINS = [];

function cors(req) {
  const o = req.headers.get('Origin') || '*';
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGINS.length ? (ALLOWED_ORIGINS.includes(o) ? o : ALLOWED_ORIGINS[0]) : o,
    'Access-Control-Allow-Headers': req.headers.get('Access-Control-Request-Headers') || 'authorization, apikey, content-type, prefer, x-client-info',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin'
  };
}

export default {
  async fetch(req) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(req) });
    if (!ALLOWED_PATHS.test(url.pathname)) return new Response('Not found', { status: 404, headers: cors(req) });
    if (ALLOWED_ORIGINS.length) {
      const o = req.headers.get('Origin');
      if (o && !ALLOWED_ORIGINS.includes(o)) return new Response('Forbidden', { status: 403 });
    }
    const upstream = new Request(TARGET + url.pathname + url.search, req);
    // WebSocket (Realtime): repassa a conexão como está
    if (req.headers.get('Upgrade') === 'websocket') return fetch(upstream);
    const res = await fetch(upstream);
    const out = new Response(res.body, res);
    for (const [k, v] of Object.entries(cors(req))) out.headers.set(k, v);
    return out;
  }
};

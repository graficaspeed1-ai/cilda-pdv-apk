# Proxy opcional (plano B quando aparece "servidor não encontrado")

Algumas operadoras/redes do Brasil não conseguem resolver `*.supabase.co` (o aparelho nem chega ao banco).
O app agora tenta o endereço direto e, se falhar, troca sozinho para um proxy. Para ativar:

1. Crie uma conta grátis em https://dash.cloudflare.com
2. **Workers & Pages → Create → Create Worker** → nome: `pdv-proxy` → **Deploy**.
3. **Edit code**, apague tudo, cole o conteúdo de `proxy/worker.js` → **Deploy**.
4. Copie o endereço do Worker (ex.: `https://pdv-proxy.seunome.workers.dev`).
5. Em `config.js`, preencha: `proxies: ['https://pdv-proxy.seunome.workers.dev']` e publique o app de novo.

Domínio próprio no Worker em vez de `workers.dev`? Adicione-o também em `connect-src` no arquivo `_headers`.
No app: **☁️ Conta → Testar conexão** mostra se o acesso Direto e o Proxy estão funcionando.
